
"""Gurobi model builder for verifying the FJSP-B/T mathematical formulation.

This script mirrors the objectives and constraints described in ``model.pdf`` and
leverages the data preparation practice used by the metaheuristic implementation
(`PMA_parameter.py`).  It can solve the provided instances twice: once for the
comprehensive cost objective and once for the makespan objective.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import gurobipy as gp
    from gurobipy import GRB
except ImportError as exc:  # pragma: no cover - defer failure until runtime
    gp = None
    GRB = None
    _IMPORT_ERROR = exc
else:
    _IMPORT_ERROR = None

# Default cost coefficients copied from ``Params.get_args``
DEFAULT_COST_WEIGHTS: Tuple[float, ...] = (1.0, 3.0, 1.0, 1.0, 1.0, 1.0)

DEFAULT_INSTANCE_ROOT = Path(__file__).resolve().parent / "FJSP_INS_gurobi"

# Default indices (0-based) describing the operation segment that contributes to the
# ``Q`` cost component, matching the decode logic in ``Decode.decode_person``.
DEFAULT_P_STAGE = 2
DEFAULT_P_PRIME_STAGE = 3


@dataclass(frozen=True)
class OperationKey:
    """Typed identifier for a job-operation pair."""

    job: int
    op: int


@dataclass(frozen=True)
class InstanceData:
    """Container for all relevant instance data."""

    n_jobs: int
    n_machines: int
    operations_per_job: List[int]
    eligible_machines: Dict[OperationKey, List[int]]
    processing_times: Dict[Tuple[int, int, int], int]
    n_batch_machines: int
    batch_capacity: int
    batch_processing_times: List[int]
    due_dates: List[int]
    cost_weights: Tuple[float, ...]
    p_stage: int
    p_prime_stage: int

    @property
    def max_operations(self) -> int:
        return max(self.operations_per_job, default=0)


@dataclass
class ModelArtifacts:
    """Handy references returned together with the constructed model."""

    model: gp.Model
    start_time: gp.Var
    end_time: gp.Var
    makespan: gp.Var
    cost_expression: gp.LinExpr
    q_time: Dict[int, gp.Var]
    delay: Dict[int, gp.Var]
    advance: Dict[int, gp.Var]
    inventory: Dict[int, gp.Var]
    batch_duration: Dict[int, gp.Var]


class InstanceParsingError(RuntimeError):
    """Raised when the instance file does not comply with the expected format."""


def load_instance(path: Path,
                  *,
                  cost_weights: Sequence[float] = DEFAULT_COST_WEIGHTS,
                  p_stage: int = DEFAULT_P_STAGE,
                  p_prime_stage: int = DEFAULT_P_PRIME_STAGE) -> InstanceData:
    """Parse an instance file located in ``path``."""

    if not path.exists():
        raise FileNotFoundError(f"Instance file not found: {path}")

    with path.open('r', encoding='ascii') as handle:
        raw_lines = [line.strip() for line in handle if line.strip()]

    if len(raw_lines) < 4:
        raise InstanceParsingError("Instance file is too short to contain mandatory sections.")

    header_tokens = raw_lines[0].split()
    if len(header_tokens) < 3:
        raise InstanceParsingError("Header line must specify n, m1, and an auxiliary value.")

    n_jobs = int(header_tokens[0])
    n_machines = int(header_tokens[1])

    if len(raw_lines) < n_jobs + 4:
        raise InstanceParsingError("Incomplete job section in instance file.")

    operations_per_job: List[int] = []
    eligible_machines: Dict[OperationKey, List[int]] = {}
    processing_times: Dict[Tuple[int, int, int], int] = {}

    for job in range(n_jobs):
        tokens = list(map(int, raw_lines[1 + job].split()))
        if not tokens:
            raise InstanceParsingError(f"Empty line for job {job}.")

        n_ops = tokens[0]
        operations_per_job.append(n_ops)
        cursor = 1

        for op in range(n_ops):
            if cursor >= len(tokens):
                raise InstanceParsingError(f"Missing machine data for job {job}, operation {op}.")
            alt_count = tokens[cursor]
            cursor += 1
            machines: List[int] = []
            for _ in range(alt_count):
                if cursor + 1 >= len(tokens):
                    raise InstanceParsingError(
                        f"Incomplete machine-time pair for job {job}, operation {op}."
                    )
                machine = tokens[cursor]
                duration = tokens[cursor + 1]
                cursor += 2
                machines.append(machine)
                processing_times[(job, op, machine)] = duration
            eligible_machines[OperationKey(job, op)] = machines

    footer_idx = 1 + n_jobs
    batch_tokens = raw_lines[footer_idx].split()
    if len(batch_tokens) != 2:
        raise InstanceParsingError("Batch line must contain exactly two integers (m2 and Q).")

    n_batch_machines = int(batch_tokens[0])
    batch_capacity = int(batch_tokens[1])

    ptb_tokens = list(map(int, raw_lines[footer_idx + 1].split()))
    if len(ptb_tokens) != n_batch_machines:
        raise InstanceParsingError(
            f"Expected {n_batch_machines} batch processing times, found {len(ptb_tokens)}."
        )

    due_tokens = list(map(int, raw_lines[footer_idx + 2].split()))
    if len(due_tokens) != n_jobs:
        raise InstanceParsingError(f"Expected {n_jobs} due dates, found {len(due_tokens)}.")

    cost_tuple = tuple(float(x) for x in cost_weights)
    if len(cost_tuple) != 6:
        raise ValueError("Exactly six cost coefficients are required.")

    if p_stage < 0 or p_prime_stage < 0:
        raise ValueError("Stage indices must be non-negative.")

    return InstanceData(
        n_jobs=n_jobs,
        n_machines=n_machines,
        operations_per_job=operations_per_job,
        eligible_machines=eligible_machines,
        processing_times=processing_times,
        n_batch_machines=n_batch_machines,
        batch_capacity=batch_capacity,
        batch_processing_times=ptb_tokens,
        due_dates=due_tokens,
        cost_weights=cost_tuple,
        p_stage=p_stage,
        p_prime_stage=p_prime_stage,
    )


def _build_big_m(data: InstanceData) -> float:
    """Compute a sufficiently large value used in disjunctive constraints."""

    sum_max_proc = 0
    for job in range(data.n_jobs):
        for op in range(data.operations_per_job[job]):
            machines = data.eligible_machines[OperationKey(job, op)]
            durations = [data.processing_times[(job, op, m)] for m in machines]
            sum_max_proc += max(durations)
    additional = sum(data.batch_processing_times) + max(data.due_dates)
    return float(sum_max_proc + additional + 10)


def build_model(data: InstanceData,
                *,
                time_limit: Optional[int] = None,
                log_to_console: bool = True) -> ModelArtifacts:
    """Instantiate the Gurobi model and all related variables."""

    if gp is None or GRB is None:
        raise ImportError("gurobipy is required to build the model") from _IMPORT_ERROR

    model = gp.Model("FJSP_BT")
    model.Params.OutputFlag = 1 if log_to_console else 0
    if time_limit is not None:
        model.Params.TimeLimit = time_limit

    jobs = range(data.n_jobs)
    machine_range = range(data.n_machines)
    batches = range(data.n_jobs)  # Maximum number of batches equals number of jobs
    batch_machines = range(data.n_batch_machines)

    big_m = _build_big_m(data)

    # Operation timing variables
    st = model.addVars(
        ((job, op) for job in jobs for op in range(data.operations_per_job[job])),
        lb=0.0,
        ub=big_m,
        name="ST",
    )
    et = model.addVars(st.keys(), lb=0.0, ub=big_m, name="ET")

    # Machine assignment variables
    x = model.addVars(
        ((job, op, machine)
         for job in jobs
         for op in range(data.operations_per_job[job])
         for machine in data.eligible_machines[OperationKey(job, op)]),
        vtype=GRB.BINARY,
        name="X",
    )

    # Sequence variables for single-type machines
    sequence: Dict[Tuple[int, int, int, int], gp.Var] = {}
    for machine in machine_range:
        eligible_ops: List[OperationKey] = [
            key for key, machines in data.eligible_machines.items() if machine in machines
        ]
        eligible_ops.sort(key=lambda item: (item.job, item.op))
        for idx_a in range(len(eligible_ops)):
            for idx_b in range(idx_a + 1, len(eligible_ops)):
                op_a = eligible_ops[idx_a]
                op_b = eligible_ops[idx_b]
                sequence[(op_a.job, op_a.op, op_b.job, op_b.op, machine)] = model.addVar(
                    vtype=GRB.BINARY,
                    name=f"Y[{op_a.job},{op_a.op},{op_b.job},{op_b.op},{machine}]",
                )
                sequence[(op_b.job, op_b.op, op_a.job, op_a.op, machine)] = model.addVar(
                    vtype=GRB.BINARY,
                    name=f"Y[{op_b.job},{op_b.op},{op_a.job},{op_a.op},{machine}]",
                )

    # Batch related variables
    z = model.addVars(((job, batch) for job in jobs for batch in batches),
                      vtype=GRB.BINARY,
                      name="Z")
    non_empty = model.addVars(batches, vtype=GRB.BINARY, name="NE")
    batch_assign = model.addVars(((batch, machine) for batch in batches for machine in batch_machines),
                                 vtype=GRB.BINARY,
                                 name="U")
    st_batch = model.addVars(batches, lb=0.0, ub=big_m, name="STB")
    et_batch = model.addVars(batches, lb=0.0, ub=big_m, name="ETB")
    batch_duration = model.addVars(batches, lb=0.0, ub=big_m, name="DurB")

    # Batch sequencing variables
    batch_sequence: Dict[Tuple[int, int, int], gp.Var] = {}
    for machine in batch_machines:
        for batch_a in batches:
            for batch_b in batches:
                if batch_a == batch_b:
                    continue
                batch_sequence[(batch_a, batch_b, machine)] = model.addVar(
                    vtype=GRB.BINARY,
                    name=f"V[{batch_a},{batch_b},{machine}]",
                )

    # Aggregated timing helpers
    prod_start = model.addVar(lb=0.0, ub=big_m, name="ProdStart")
    prod_end = model.addVar(lb=0.0, ub=big_m, name="ProdEnd")
    makespan = model.addVar(lb=0.0, ub=big_m, name="Makespan")

    # Job level quantities
    job_fjsp_completion = model.addVars(jobs, lb=0.0, ub=big_m, name="JobEnd")
    job_batch_start = model.addVars(jobs, lb=0.0, ub=big_m, name="JobBatchStart")
    job_completion = model.addVars(jobs, lb=0.0, ub=big_m, name="JobBatchEnd")

    inventory = model.addVars(jobs, lb=0.0, ub=big_m, name="Inventory")
    delay = model.addVars(jobs, lb=0.0, ub=big_m, name="Delay")
    advance = model.addVars(jobs, lb=0.0, ub=big_m, name="Advance")
    q_time = model.addVars(jobs, lb=0.0, ub=big_m, name="QTime")

    model.update()

    # -- Core constraints --------------------------------------------------

    # Start/end linkage and machine assignment
    for job in jobs:
        for op in range(data.operations_per_job[job]):
            machines = data.eligible_machines[OperationKey(job, op)]
            model.addConstr(gp.quicksum(x[job, op, machine] for machine in machines) == 1,
                            name=f"Assign[{job},{op}]")
            model.addConstr(
                et[job, op] == st[job, op] + gp.quicksum(
                    data.processing_times[(job, op, machine)] * x[job, op, machine]
                    for machine in machines
                ),
                name=f"ProcTime[{job},{op}]",
            )

            if op > 0:
                model.addConstr(st[job, op] >= et[job, op - 1], name=f"JobSeq[{job},{op}]")

            # Track job completion for inventory accounting
            model.addConstr(job_fjsp_completion[job] >= et[job, op],
                            name=f"JobEndLB[{job},{op}]")

            # Global span helpers
            model.addConstr(prod_start <= st[job, op], name=f"ProdStartUB[{job},{op}]")
            model.addConstr(prod_end >= et[job, op], name=f"ProdEndLB[{job},{op}]")

    # Disjunctive constraints on single-type machines
    for (job_a, op_a, job_b, op_b, machine), var in sequence.items():
        # Only enforce for one direction (avoid duplicates)
        if (job_a, op_a) == (job_b, op_b):
            continue
        # Pair variables are created twice (a->b and b->a); restrict to avoid duplicates
        if (job_a, op_a) < (job_b, op_b):
            forward = var
            backward = sequence[(job_b, op_b, job_a, op_a, machine)]

            model.addConstr(st[job_b, op_b] >= et[job_a, op_a] - big_m * (1 - forward),
                            name=f"MachSeqF[{job_a},{op_a},{job_b},{op_b},{machine}]")
            model.addConstr(st[job_a, op_a] >= et[job_b, op_b] - big_m * (1 - backward),
                            name=f"MachSeqB[{job_a},{op_a},{job_b},{op_b},{machine}]")

            model.addConstr(forward <= x[job_a, op_a, machine],
                            name=f"SeqCap1[{job_a},{op_a},{job_b},{op_b},{machine}]")
            model.addConstr(forward <= x[job_b, op_b, machine],
                            name=f"SeqCap2[{job_a},{op_a},{job_b},{op_b},{machine}]")
            model.addConstr(backward <= x[job_a, op_a, machine],
                            name=f"SeqCap3[{job_b},{op_b},{job_a},{op_a},{machine}]")
            model.addConstr(backward <= x[job_b, op_b, machine],
                            name=f"SeqCap4[{job_b},{op_b},{job_a},{op_a},{machine}]")

            model.addConstr(forward + backward <= 1,
                            name=f"SeqOneDirUB[{job_a},{op_a},{job_b},{op_b},{machine}]")
            model.addConstr(forward + backward >= x[job_a, op_a, machine] + x[job_b, op_b, machine] - 1,
                            name=f"SeqOneDirLB[{job_a},{op_a},{job_b},{op_b},{machine}]")

    # Batch assignment and capacity
    for job in jobs:
        model.addConstr(gp.quicksum(z[job, batch] for batch in batches) == 1,
                        name=f"BatchAssign[{job}]")

    for batch in batches:
        model.addConstr(gp.quicksum(z[job, batch] for job in jobs) <= data.batch_capacity * non_empty[batch],
                        name=f"BatchCapUB[{batch}]")
        model.addConstr(gp.quicksum(z[job, batch] for job in jobs) >= non_empty[batch],
                        name=f"BatchCapLB[{batch}]")
        model.addConstr(gp.quicksum(batch_assign[batch, machine] for machine in batch_machines) == non_empty[batch],
                        name=f"BatchMachine[{batch}]")
        model.addConstr(st_batch[batch] <= big_m * non_empty[batch], name=f"BatchStartUB[{batch}]")
        model.addConstr(et_batch[batch] <= big_m * non_empty[batch], name=f"BatchEndUB[{batch}]")
        model.addConstr(batch_duration[batch] <= big_m * non_empty[batch], name=f"BatchDurUB[{batch}]")

        for machine_idx, proc_time in enumerate(data.batch_processing_times):
            model.addConstr(
                et_batch[batch] >= st_batch[batch] + proc_time - big_m * (1 - batch_assign[batch, machine_idx]),
                name=f"BatchProc[{batch},{machine_idx}]",
            )

        # Batch duration definition (ties to actual start/end when non-empty)
        model.addConstr(batch_duration[batch] >= et_batch[batch] - st_batch[batch],
                        name=f"DurLB[{batch}]")
        model.addConstr(batch_duration[batch] <= et_batch[batch] - st_batch[batch] + big_m * (1 - non_empty[batch]),
                        name=f"DurUBTight[{batch}]")

    # Batch sequencing constraints
    for machine in batch_machines:
        for batch_a in batches:
            for batch_b in batches:
                if batch_a >= batch_b:
                    continue
                forward = batch_sequence[(batch_a, batch_b, machine)]
                backward = batch_sequence[(batch_b, batch_a, machine)]

                model.addConstr(st_batch[batch_b] >= et_batch[batch_a] - big_m * (1 - forward),
                                name=f"BatchSeqF[{batch_a},{batch_b},{machine}]")
                model.addConstr(st_batch[batch_a] >= et_batch[batch_b] - big_m * (1 - backward),
                                name=f"BatchSeqB[{batch_a},{batch_b},{machine}]")

                model.addConstr(forward <= batch_assign[batch_a, machine],
                                name=f"BatchSeqCap1[{batch_a},{batch_b},{machine}]")
                model.addConstr(forward <= batch_assign[batch_b, machine],
                                name=f"BatchSeqCap2[{batch_a},{batch_b},{machine}]")
                model.addConstr(backward <= batch_assign[batch_a, machine],
                                name=f"BatchSeqCap3[{batch_b},{batch_a},{machine}]")
                model.addConstr(backward <= batch_assign[batch_b, machine],
                                name=f"BatchSeqCap4[{batch_b},{batch_a},{machine}]")

                model.addConstr(forward + backward <= 1,
                                name=f"BatchSeqOneDirUB[{batch_a},{batch_b},{machine}]")
                model.addConstr(forward + backward >= batch_assign[batch_a, machine] + batch_assign[batch_b, machine] - 1,
                                name=f"BatchSeqOneDirLB[{batch_a},{batch_b},{machine}]")

    # Job-to-batch timing linkage and inventory-related expressions
    for job in jobs:
        model.addConstr(job_batch_start[job] >= job_fjsp_completion[job], name=f"BatchStartLB[{job}]")

        for batch in batches:
            model.addConstr(job_batch_start[job] >= st_batch[batch] - big_m * (1 - z[job, batch]),
                            name=f"JobBatchStartLB[{job},{batch}]")
            model.addConstr(job_batch_start[job] <= st_batch[batch] + big_m * (1 - z[job, batch]),
                            name=f"JobBatchStartUB[{job},{batch}]")
            model.addConstr(job_completion[job] >= et_batch[batch] - big_m * (1 - z[job, batch]),
                            name=f"JobBatchEndLB[{job},{batch}]")
            model.addConstr(job_completion[job] <= et_batch[batch] + big_m * (1 - z[job, batch]),
                            name=f"JobBatchEndUB[{job},{batch}]")

        model.addConstr(inventory[job] >= job_batch_start[job] - job_fjsp_completion[job],
                        name=f"InventoryLB[{job}]")
        model.addConstr(delay[job] >= job_completion[job] - data.due_dates[job],
                        name=f"DelayLB[{job}]")
        model.addConstr(advance[job] >= data.due_dates[job] - job_completion[job],
                        name=f"AdvanceLB[{job}]")

        # Define Q-time difference between selected operations
        if data.p_stage >= data.operations_per_job[job] or data.p_prime_stage >= data.operations_per_job[job]:
            raise InstanceParsingError(
                f"Configured stage indices ({data.p_stage}, {data.p_prime_stage}) exceed job {job}'s operations."
            )
        model.addConstr(
            q_time[job] >= st[job, data.p_prime_stage] - et[job, data.p_stage],
            name=f"QTimeLB[{job}]",
        )
        model.addConstr(
            q_time[job] <= st[job, data.p_prime_stage] - et[job, data.p_stage],
            name=f"QTimeUB[{job}]",
        )

        model.addConstr(makespan >= job_completion[job] - prod_start, name=f"MakespanLB[{job}]")

    # Non-negativity for slack variables
    for job in jobs:
        model.addConstr(inventory[job] >= 0.0, name=f"InventoryNonNeg[{job}]")
        model.addConstr(delay[job] >= 0.0, name=f"DelayNonNeg[{job}]")
        model.addConstr(advance[job] >= 0.0, name=f"AdvanceNonNeg[{job}]")

    # Compose the total cost expression
    c0, c1, c2, c3, c4, c5 = data.cost_weights
    cost_expr = (
        c0 * (prod_end - prod_start)
        + c1 * gp.quicksum(q_time[job] for job in jobs)
        + c2 * gp.quicksum(batch_duration[batch] for batch in batches)
        + c3 * gp.quicksum(inventory[job] for job in jobs)
        + c4 * gp.quicksum(delay[job] for job in jobs)
        + c5 * gp.quicksum(advance[job] for job in jobs)
    )

    return ModelArtifacts(
        model=model,
        start_time=prod_start,
        end_time=prod_end,
        makespan=makespan,
        cost_expression=cost_expr,
        q_time=q_time,
        delay=delay,
        advance=advance,
        inventory=inventory,
        batch_duration=batch_duration,
    )




def _resolve_instance_targets(target: Path) -> List[Path]:
    """Expand a target path into one or more instance files."""

    if target.is_file():
        return [target]

    if target.is_dir():
        candidates = sorted(
            p for p in target.iterdir() if p.is_file() and p.suffix.lower() == ".txt"
        )
        if not candidates:
            raise FileNotFoundError(f"No .txt instances found under {target}.")
        return candidates

    raise FileNotFoundError(f"Instance path does not exist: {target}")

@dataclass
class SolveResult:
    objective_name: str
    objective_value: Optional[float]
    status: int
    gap: Optional[float]
    runtime: Optional[float]
    cost_value: Optional[float] = None
    makespan_value: Optional[float] = None
    message: Optional[str] = None


@dataclass
class InstanceProgress:
    path: Path
    size_label: Optional[str] = None
    cost_result: Optional[SolveResult] = None
    makespan_result: Optional[SolveResult] = None


REPORT_DEFAULT_PATH = Path(__file__).with_name("model_validation_report.txt")


def _format_size_label(data: InstanceData) -> str:
    return f"{data.n_jobs}×{data.n_machines}×{data.n_batch_machines}×{data.batch_capacity}"


def _format_metric(result: Optional[SolveResult], attr: str, *, digits: int = 3) -> str:
    if result is None:
        return "--"
    value = getattr(result, attr, None)
    if value is None:
        return "--"
    return f"{value:.{digits}f}"


def _write_table_report(output_path: Path, progress: Sequence[InstanceProgress]) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    header = (
        "No.	Size	Ob1 priority = 1，Ob2 priority = 0		Ob1 priority = 0，Ob2 priority = 1\n"
        "		Ob1	Ob2	Time (s)		Ob1	Ob2	Time (s)\n"
    )
    lines = [header]
    for index, item in enumerate(progress, start=1):
        size_label = item.size_label or "--"
        cost_ob1 = _format_metric(item.cost_result, "cost_value")
        cost_ob2 = _format_metric(item.cost_result, "makespan_value")
        cost_time = _format_metric(item.cost_result, "runtime", digits=2)
        makespan_ob1 = _format_metric(item.makespan_result, "cost_value")
        makespan_ob2 = _format_metric(item.makespan_result, "makespan_value")
        makespan_time = _format_metric(item.makespan_result, "runtime", digits=2)
        line = (
            f"{index}\t{size_label}\t{cost_ob1}\t{cost_ob2}\t{cost_time}"
            f"\t\t{makespan_ob1}\t{makespan_ob2}\t{makespan_time}\n"
        )
        lines.append(line)
    with output_path.open("w", encoding="utf-8") as handle:
        handle.writelines(lines)


def solve_for_objective(data: InstanceData,
                        objective: str,
                        *,
                        time_limit: Optional[int] = None,
                        log_to_console: bool = True) -> SolveResult:
    """Build and solve the model for the requested objective."""

    artifacts = build_model(data, time_limit=time_limit, log_to_console=log_to_console)
    model = artifacts.model

    if objective == "cost":
        model.setObjective(artifacts.cost_expression, GRB.MINIMIZE)
    elif objective == "makespan":
        model.setObjective(artifacts.makespan, GRB.MINIMIZE)
    else:
        raise ValueError(f"Unsupported objective: {objective}")

    objective_value: Optional[float] = None
    gap: Optional[float] = None
    runtime: Optional[float] = None
    message: Optional[str] = None
    status: int = -1
    cost_value: Optional[float] = None
    makespan_value: Optional[float] = None

    try:
        model.optimize()
    except gp.GurobiError as err:
        status = getattr(err, "errno", -1) or -1
        message = str(err)
        try:
            runtime = float(model.Runtime)
        except Exception:
            runtime = None
    else:
        status = model.Status
        if model.SolCount > 0:
            objective_value = model.ObjVal
            gap = model.MIPGap if model.IsMIP else 0.0
            try:
                cost_value = float(artifacts.cost_expression.getValue())
            except Exception:
                cost_value = None
            try:
                makespan_value = float(artifacts.makespan.X)
            except Exception:
                makespan_value = None
        if model.Runtime is not None:
            runtime = float(model.Runtime)
    finally:
        model.dispose()

    return SolveResult(
        objective_name=objective,
        objective_value=objective_value,
        status=status,
        gap=gap,
        runtime=runtime,
        cost_value=cost_value,
        makespan_value=makespan_value,
        message=message,
    )

def _export_results(output_path: Path, records: Sequence[Tuple[Path, SolveResult]]) -> None:
    """Persist run summaries to ``output_path`` in CSV format."""

    if not records:
        return

    output_path.parent.mkdir(parents=True, exist_ok=True)
    needs_header = not output_path.exists()

    with output_path.open("a", encoding="utf-8") as handle:
        if needs_header:
            handle.write("instance,objective,status,objective_value,gap,runtime,message\n")
        for instance_path, result in records:
            objective_value = "" if result.objective_value is None else f"{result.objective_value:.6f}"
            gap = "" if result.gap is None else f"{result.gap:.6f}"
            runtime = "" if result.runtime is None else f"{result.runtime:.3f}"
            message = "" if not result.message else result.message.replace("\n", " ").replace(",", ";")
            handle.write(
                f"{instance_path.as_posix()},{result.objective_name},{result.status},{objective_value},{gap},{runtime},{message}\n"
            )



def run_cli(arguments: Optional[Sequence[str]] = None) -> List[Tuple[Path, SolveResult]]:
    """Entry point used by the CLI and unit-style callers."""

    if gp is None or GRB is None:
        raise ImportError("gurobipy is required to build the model") from _IMPORT_ERROR

    parser = argparse.ArgumentParser(description="Solve FJSP-B/T verification models with Gurobi.")
    parser.add_argument(
        "target",
        nargs="?",
        type=Path,
        default=DEFAULT_INSTANCE_ROOT,
        help=(
            "Path to an instance file or a directory containing .txt instances. "
            "Defaults to the bundled FJSP_INS_gurobi folder."
        ),
    )
    parser.add_argument(
        "--objective",
        choices=("cost", "makespan", "both"),
        default="both",
        help="Which objective to optimize.",
    )
    parser.add_argument(
        "--time-limit",
        type=int,
        default=3600,
        help="Time limit in seconds for each optimization run.",
    )
    parser.add_argument(
        "--silent",
        action="store_true",
        help="Silence the Gurobi log output.",
    )
    parser.add_argument(
        "--p-stage",
        type=int,
        default=DEFAULT_P_STAGE,
        help="0-based index of operation marking the start of the time-lag section.",
    )
    parser.add_argument(
        "--p-prime-stage",
        type=int,
        default=DEFAULT_P_PRIME_STAGE,
        help="0-based index of operation marking the end of the time-lag section.",
    )
    parser.add_argument(
        "--cost-weights",
        type=float,
        nargs=6,
        metavar=("C0", "C1", "C2", "C3", "C4", "C5"),
        default=DEFAULT_COST_WEIGHTS,
        help="Cost coefficients aligned with the metaheuristic implementation.",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=REPORT_DEFAULT_PATH,
        help="TXT file to update in real time with both objectives.",
    )

    parser.add_argument(
        "--export",
        type=Path,
        help="Optional CSV file to append aggregated results.",
    )

    args = parser.parse_args(arguments)

    report_path = args.report
    cost_weights = tuple(args.cost_weights)
    instances = _resolve_instance_targets(args.target)

    progress = [InstanceProgress(path=instance_path) for instance_path in instances]
    _write_table_report(report_path, progress)

    objectives: Iterable[str]
    if args.objective == "both":
        objectives = ("cost", "makespan")
    else:
        objectives = (args.objective,)

    aggregated: List[Tuple[Path, SolveResult]] = []

    for index, instance_path in enumerate(instances):
        progress_entry = progress[index]
        print("=" * 72)
        print(f"Instance: {instance_path}")

        data = load_instance(
            instance_path,
            cost_weights=cost_weights,
            p_stage=args.p_stage,
            p_prime_stage=args.p_prime_stage,
        )

        progress_entry.size_label = _format_size_label(data)
        _write_table_report(report_path, progress)

        for objective in objectives:
            result = solve_for_objective(
                data,
                objective,
                time_limit=args.time_limit,
                log_to_console=not args.silent,
            )
            aggregated.append((instance_path, result))

            if objective == "cost":
                progress_entry.cost_result = result
            elif objective == "makespan":
                progress_entry.makespan_result = result
            _write_table_report(report_path, progress)

            print("-" * 72)
            print(f"Objective: {result.objective_name}")
            print(f"Status: {result.status}")
            if result.message:
                print(f"Message: {result.message}")
            if result.objective_value is not None:
                print(f"Objective value: {result.objective_value:.3f}")
            if result.gap is not None:
                print(f"MIP gap: {result.gap:.4f}")
            if result.runtime is not None:
                print(f"Runtime: {result.runtime:.2f} s")

    if args.export:
        _export_results(args.export, aggregated)

    return aggregated



if __name__ == "__main__":
    run_cli()
